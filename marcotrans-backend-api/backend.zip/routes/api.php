<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\PackageController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');



/*
|--------------------------------------------------------------------------
| API Routes - MarcoTrans Platform
|--------------------------------------------------------------------------
*/

// Routes Publiques (Accessibles sans connexion)
Route::post('/login', [AuthController::class, 'login']);

// Routes Protégées (Nécessitent un Bearer Token valide dans le Header)
Route::middleware('auth:sanctum')->group(function () {

    Route::post('/logout', [AuthController::class, 'logout']);

    // Gestion des Commandes Commerciales
    Route::get('/orders', [OrderController::class, 'index']);
    Route::post('/orders', [OrderController::class, 'store']);
    Route::get('/orders/{reference}', [OrderController::class, 'show']);

    // Gestion de la Logistique & des Colis
    Route::post('/packages', [PackageController::class, 'store']);
    Route::patch('/packages/{id}/status', [PackageController::class, 'updateStatus']);
    Route::post('/packages/checkpoints', [PackageController::class, 'addCheckpoint']);
});

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Package extends Model
{
    use HasFactory;
    //
    protected $fillable = [
        'order_id',
        'package_type',
        'total_weight',
        'dimensions',
        'delivery_status',
    ];

    protected $casts = [
        'total_weight' => 'decimal:2',
    ];

    // Relation 1-N inversée : Le colis appartient à une commande (peut être nul au début)
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    // Relation 1-N : Un colis passe par plusieurs checkpoints internationaux
    public function shipmentCheckpoints()
    {
        return $this->hasMany(ShipmentCheckpoint::class)->orderBy('sequence_order', 'asc');
    }
}

<?php

namespace App\Repositories\Eloquent;

use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class OrderRepository implements OrderRepositoryInterface
{
    public function createWithItems(array $orderData, array $items): Order
    {
        // Utilisation d'une transaction de base de données pour garantir l'intégrité (Commande + Articles reliés)
        return DB::transaction(function () use ($orderData, $items) {
            $order = Order::create($orderData);

            foreach ($items as $item) {
                $order->articles()->attach($item['article_id'], [
                    'quantity' => $item['quantity']
                ]);
            }

            return $order->load('articles');
        });
    }

    public function findByReference(string $reference): ?Order
    {
        return Order::with(['client', 'articles', 'packages'])->where('reference', $reference)->first();
    }

    public function getClientOrderHistory(int $clientId): Collection
    {
        return Order::where('client_id', $clientId)->orderBy('created_at', 'desc')->get();
    }

    public function updateStatus(int $orderId, string $status): bool
    {
        $order = Order::find($orderId);
        if (!$order) return false;
        return $order->update(['order_status' => $status]);
    }
}

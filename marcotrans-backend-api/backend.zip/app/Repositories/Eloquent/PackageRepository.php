<?php

namespace App\Repositories\Eloquent;

use App\Models\Package;
use App\Repositories\Contracts\PackageRepositoryInterface;
use Illuminate\Support\Collection;

class PackageRepository implements PackageRepositoryInterface
{
    public function create(array $data): Package
    {
        return Package::create($data);
    }

    public function findWithTracking(int $id): ?Package
    {
        // Charge le colis avec sa frise chronologique triée de manière séquentielle
        return Package::with(['order', 'shipmentCheckpoints'])->find($id);
    }

    public function updateDeliveryStatus(int $packageId, string $status): bool
    {
        $package = Package::find($packageId);
        if (!$package) return false;
        return $package->update(['delivery_status' => $status]);
    }

    public function addCheckpoint(int $packageId, array $checkpointData): bool
    {
        $package = Package::find($packageId);
        if (!$package) return false;

        $package->shipmentCheckpoints()->create($checkpointData);
        return true;
    }

    public function getPackagesByStatus(string $status): Collection
    {
        return Package::where('delivery_status', $status)->with('order.client')->get();
    }
}

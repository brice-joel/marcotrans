<?php

namespace App\Repositories\Contracts;

use App\Models\Order;
use Illuminate\Support\Collection;

interface OrderRepositoryInterface
{
    public function createWithItems(array $orderData, array $items): Order;
    public function findByReference(string $reference): ?Order;
    public function getClientOrderHistory(int $clientId): Collection;
    public function updateStatus(int $orderId, string $status): bool;
}

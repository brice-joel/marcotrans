<?php

namespace App\Repositories\Contracts;

use App\Models\User;
use Illuminate\Support\Collection;

interface UserRepositoryInterface
{
    public function create(array $data): User;
    public function update(int $id, array $data): bool;
    public function find(int $id): ?User;
    public function getAvailableDrivers(): Collection; // Utile pour l'affectation immédiate d'une moto
}

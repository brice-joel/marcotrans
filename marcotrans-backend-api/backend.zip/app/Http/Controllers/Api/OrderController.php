<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Resources\OrderResource;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class OrderController extends Controller
{
    protected $orderRepository;

    public function __construct(OrderRepositoryInterface $orderRepository)
    {
        $this->orderRepository = $orderRepository;
    }

    /**
     * Liste des commandes du client connecté (Historique).
     */
    public function index(): AnonymousResourceCollection
    {
        $clientId = 14; // auth()->id();
        $orders = $this->orderRepository->getClientOrderHistory($clientId);

        return OrderResource::collection($orders);
    }

    /**
     * Création d'une nouvelle commande avec ses articles (Transaction sécurisée).
     */
    public function store(StoreOrderRequest $request): OrderResource
    {
        // Extraction des données de la commande et du tableau d'articles
        $orderData = $request->only(['client_id', 'order_type', 'delivery_address', 'total_price']);
        $items = $request->input('items');

        // Génération automatique d'une référence unique pour MarcoTrans
        $orderData['reference'] = 'MT-' . now()->year . '-' . strtoupper(bin2hex(random_bytes(3)));
        $orderData['order_status'] = 'pending';

        // Persistance via la couche Repository
        $order = $this->orderRepository->createWithItems($orderData, $items);

        return new OrderResource($order);
    }

    /**
     * Obtenir les détails d'une commande spécifique via sa référence unique (Suivi Client).
     */
    public function show(string $reference)
    {
        $order = $this->orderRepository->findByReference($reference);

        if (!$order) {
            return response()->json(['message' => 'Commande introuvable.'], 404);
        }

        // On charge dynamiquement les colis et leurs frises chronologiques (checkpoints)
        $order->load(['articles', 'packages.shipmentCheckpoints']);

        return new OrderResource($order);
    }
}

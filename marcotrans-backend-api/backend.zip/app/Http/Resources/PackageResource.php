<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PackageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'order_id' => $this->order_id,
            'type' => $this->package_type,
            'weight' => (float) $this->total_weight,
            'dimensions' => $this->dimensions,
            'status' => $this->delivery_status, // Le statut standardisé issu de notre correction
            // Inclusion automatique et ordonnée des étapes de suivi si la relation est chargée
            'tracking_timeline' => CheckpointResource::collection($this->whenLoaded('shipmentCheckpoints')),
            'created_at' => $this->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
